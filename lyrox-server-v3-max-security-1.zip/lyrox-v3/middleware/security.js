// middleware/security.js — Tüm güvenlik katmanları
const rateLimit  = require('express-rate-limit');
const slowDown   = require('express-slow-down');
const helmet     = require('helmet');
const cors       = require('cors');
const hpp        = require('hpp');
const mongoSanitize = require('express-mongo-sanitize');
const jwt        = require('jsonwebtoken');
const { scanBody, generateSecureToken } = require('../utils/security');
const { audit, DB } = require('../utils/database');

// ── IP Reputation Tracker ─────────────────────────────────────────────────
const ipReputation = new Map(); // ip → { score, blockedUntil }
const BLOCK_THRESHOLD = 100;

function getReputation(ip) {
  return ipReputation.get(ip) || { score: 0, blockedUntil: 0 };
}

function addScore(ip, points) {
  const rep = getReputation(ip);
  rep.score += points;
  if (rep.score >= BLOCK_THRESHOLD && !rep.blockedUntil) {
    rep.blockedUntil = Date.now() + 24 * 60 * 60 * 1000; // 24 saat
    console.warn(`[SECURITY] IP BLOCKED: ${ip} (score: ${rep.score})`);
  }
  ipReputation.set(ip, rep);
}

function isBlocked(ip) {
  const rep = getReputation(ip);
  if (rep.blockedUntil && Date.now() > rep.blockedUntil) {
    rep.blockedUntil = 0;
    rep.score = Math.floor(rep.score / 2); // Ceza yarıya düş
    ipReputation.set(ip, rep);
    return false;
  }
  return rep.blockedUntil > 0;
}

// ── 1. IP Reputation Gate ─────────────────────────────────────────────────
const ipGate = (req, res, next) => {
  const ip = req.ip;
  if (isBlocked(ip)) {
    audit('BLOCKED_IP', ip);
    return res.status(403).json({ error: 'Access Denied' });
  }
  next();
};

// ── 2. Injection Scanner (her request body'yi tara) ──────────────────────
const injectionScanner = (req, res, next) => {
  if (req.body && scanBody(req.body)) {
    addScore(req.ip, 30);
    audit('INJECTION_ATTEMPT', req.ip, null, { path: req.path, body: JSON.stringify(req.body).substring(0, 200) });
    return res.status(400).json({ error: 'Invalid input' });
  }
  next();
};

// ── 3. Rate Limiters ─────────────────────────────────────────────────────

// Global — herkes için
const globalLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 120,
  standardHeaders: true,
  legacyHeaders: false,
  skip: (req) => req.ip === '127.0.0.1',
  handler: (req, res) => {
    addScore(req.ip, 5);
    audit('RATE_LIMITED', req.ip);
    res.status(429).json({ error: 'Too many requests' });
  },
});

// Auth endpoint'leri için çok sıkı
const authLimiter = rateLimit({
  windowMs: parseInt(process.env.LOGIN_WINDOW_MINUTES || 15) * 60 * 1000,
  max: parseInt(process.env.MAX_LOGIN_ATTEMPTS || 5),
  skipSuccessfulRequests: true,
  handler: (req, res) => {
    addScore(req.ip, 20);
    audit('AUTH_RATE_LIMITED', req.ip);
    res.status(429).json({ error: 'Too many attempts. Try again later.' });
  },
});

// Yavaşlatma — bot'ları sıkıştır
const speedLimiter = slowDown({
  windowMs: 15 * 60 * 1000,
  delayAfter: 30,
  delayMs: (hits) => Math.min(hits * 300, 5000),
});

// API'ye genel limiter
const apiLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 60,
  handler: (req, res) => {
    addScore(req.ip, 3);
    res.status(429).json({ error: 'API rate limit exceeded' });
  },
});

// ── 4. Helmet (Security Headers) ─────────────────────────────────────────
const helmetConfig = helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc:     ["'self'"],
      scriptSrc:      ["'self'", "'unsafe-inline'"],
      styleSrc:       ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc:        ["'self'", "https://fonts.gstatic.com"],
      imgSrc:         ["'self'", "data:", "blob:"],
      connectSrc:     ["'self'"],
      objectSrc:      ["'none'"],
      frameSrc:       ["'none'"],
      baseUri:        ["'self'"],
      formAction:     ["'self'"],
      frameAncestors: ["'none'"],
      upgradeInsecureRequests: [],
    },
  },
  hsts:            { maxAge: 63072000, includeSubDomains: true, preload: true },
  frameguard:      { action: 'deny' },
  noSniff:         true,
  xssFilter:       true,
  referrerPolicy:  { policy: 'strict-origin-when-cross-origin' },
  permissionsPolicy: {
    features: {
      geolocation:    [],
      microphone:     [],
      camera:         [],
      payment:        [],
      usb:            [],
      accelerometer:  [],
      gyroscope:      [],
    },
  },
});

// ── 5. CORS ───────────────────────────────────────────────────────────────
const allowedOrigins = process.env.ALLOWED_ORIGINS
  ? process.env.ALLOWED_ORIGINS.split(',').map(s => s.trim())
  : ['http://localhost:3000'];

const corsConfig = cors({
  origin: (origin, cb) => {
    if (!origin || allowedOrigins.includes(origin)) return cb(null, true);
    cb(new Error('CORS Policy Violation'));
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-CSRF-Token'],
  maxAge: 3600,
});

// ── 6. Bot / Scanner Detector ─────────────────────────────────────────────
const MALICIOUS_UA = [
  /sqlmap|nikto|havij|acunetix|nessus|openvas/i,
  /masscan|nmap|zmap|shodan/i,
  /python-requests\/|go-http-client|java\/|libwww-perl/i,
  /zgrab|nuclei|wfuzz|dirbuster|gobuster/i,
];

const botDetector = (req, res, next) => {
  const ua = req.get('user-agent') || '';
  if (!ua) {
    addScore(req.ip, 5);
  }
  if (MALICIOUS_UA.some(p => p.test(ua))) {
    addScore(req.ip, 40);
    audit('MALICIOUS_BOT', req.ip, null, { ua });
    return res.status(403).json({ error: 'Forbidden' });
  }
  next();
};

// ── 7. Request Size Kontrolü ──────────────────────────────────────────────
const sizeGuard = (req, res, next) => {
  const contentLength = parseInt(req.get('content-length') || 0);
  if (contentLength > 5 * 1024 * 1024) { // 5MB
    addScore(req.ip, 10);
    return res.status(413).json({ error: 'Payload too large' });
  }
  next();
};

// ── 8. JWT Auth Middleware ────────────────────────────────────────────────
const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET || JWT_SECRET.length < 32) {
  console.error('❌ CRITICAL: JWT_SECRET is not set or too short!');
  // Production'da çık, dev'de devam et
  if (process.env.NODE_ENV === 'production') process.exit(1);
}

function requireAuth(req, res, next) {
  const header = req.headers.authorization;
  if (!header?.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  const token = header.slice(7);
  try {
    const payload = jwt.verify(token, JWT_SECRET, {
      algorithms: ['HS256'],   // Sadece HS256, algorithm confusion saldırısına karşı
      issuer: 'lyrox-server',  // Token'ın kim tarafından üretildiğini doğrula
    });
    req.user = payload;

    // Session token'ı veritabanında da kontrol et (revocation için)
    const session = DB.sessions.get(payload.uid);
    if (!session || session.tokenHash !== hashToken(token)) {
      return res.status(401).json({ error: 'Session expired' });
    }

    session.lastSeen = Date.now();
    next();
  } catch (err) {
    addScore(req.ip, 2);
    if (err.name === 'TokenExpiredError') {
      return res.status(401).json({ error: 'Token expired' });
    }
    return res.status(401).json({ error: 'Invalid token' });
  }
}

function requireAdmin(req, res, next) {
  if (!req.user?.admin) {
    audit('UNAUTHORIZED_ADMIN_ACCESS', req.ip, req.user?.uid);
    return res.status(403).json({ error: 'Forbidden' });
  }
  next();
}

// Token hash'i (tam token'ı DB'de saklamak yerine hash'ini sakla)
const crypto = require('crypto');
function hashToken(token) {
  return crypto.createHash('sha256').update(token).digest('hex');
}

// JWT üretici
function signJWT(payload) {
  return jwt.sign(
    { ...payload, iat: Math.floor(Date.now() / 1000) },
    JWT_SECRET,
    {
      algorithm: 'HS256',
      expiresIn: '7d',
      issuer: 'lyrox-server',
    }
  );
}

// ── 9. Security Response Headers (helmet'e ek) ───────────────────────────
const extraHeaders = (req, res, next) => {
  res.set('X-Request-ID', generateSecureToken(8));       // Her request için benzersiz ID
  res.set('X-Content-Type-Options', 'nosniff');
  res.set('X-Frame-Options', 'DENY');
  res.set('X-XSS-Protection', '1; mode=block');
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  res.set('Pragma', 'no-cache');
  // Server imzasını gizle
  res.removeHeader('X-Powered-By');
  next();
};

// ── 10. Audit Middleware ─────────────────────────────────────────────────
const auditMiddleware = (req, res, next) => {
  req._startTime = Date.now();
  res.on('finish', () => {
    if (res.statusCode >= 400) {
      audit('HTTP_ERROR', req.ip, req.user?.uid, {
        method: req.method,
        path: req.path,
        status: res.statusCode,
        ms: Date.now() - req._startTime,
      });
    }
  });
  next();
};

module.exports = {
  ipGate,
  injectionScanner,
  globalLimiter,
  authLimiter,
  speedLimiter,
  apiLimiter,
  helmetConfig,
  corsConfig,
  botDetector,
  sizeGuard,
  extraHeaders,
  auditMiddleware,
  requireAuth,
  requireAdmin,
  hashToken,
  signJWT,
  addScore,
};
