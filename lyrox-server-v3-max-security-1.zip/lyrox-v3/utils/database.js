// utils/database.js — In-memory veritabanı + audit log
const { generateUID } = require('./security');

const DB = {
  users:   [],  // Kullanıcılar
  msgs:    [],  // Mesajlar
  tickets: [],  // Destek talepleri
  audit:   [],  // Güvenlik audit log'u (kim ne zaman ne yaptı)
  sessions: new Map(), // uid → { tokenHash, createdAt, lastSeen, ip, ua }
};

// Audit log - her önemli işlemi kaydet
function audit(action, ip, uid = null, details = {}) {
  DB.audit.push({
    ts:      new Date().toISOString(),
    action,  // 'LOGIN', 'REGISTER', 'FAILED_LOGIN', 'DELETE_USER', vb.
    ip,
    uid,
    details,
  });
  // Son 10.000 kaydı tut
  if (DB.audit.length > 10000) DB.audit.shift();
  console.log(`[AUDIT] ${new Date().toISOString()} | ${action} | IP:${ip} | UID:${uid || '-'}`);
}

// Güvenli kullanıcı kaydı (passwordHash asla dışarı çıkmaz)
function publicUser(u) {
  if (!u) return null;
  return {
    uid: u.uid, name: u.name, username: u.username,
    avatar: u.avatar, online: u.online, premium: u.premium,
    nameColor: u.nameColor, bio: u.bio, admin: !!u.admin,
    badgeIcon: u.badgeIcon, profileIcon: u.profileIcon,
  };
}

function adminUser(u) {
  if (!u) return null;
  return { ...publicUser(u), email: u.email, createdAt: u.createdAt };
}

function findUser(uid) {
  return DB.users.find(u => u.uid === uid) || null;
}

function findByIdent(ident) {
  const low = ident.toLowerCase();
  return DB.users.find(u =>
    u.username.toLowerCase() === low ||
    u.email.toLowerCase() === low
  ) || null;
}

module.exports = { DB, audit, publicUser, adminUser, findUser, findByIdent };
