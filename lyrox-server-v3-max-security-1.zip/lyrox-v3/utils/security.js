// utils/security.js - Kriptografi ve güvenlik yardımcıları
const crypto = require('crypto');
const xss    = require('xss');

// ── AES-256-GCM Şifreleme (authenticated encryption) ──────────────────────
// GCM modu hem şifreler hem integrity doğrular (tampering tespit eder)
const ALGO = 'aes-256-gcm';

function deriveKey(secret) {
  // PBKDF2 ile güvenli anahtar türetme
  return crypto.pbkdf2Sync(
    secret,
    'lyrox-salt-v3',
    100000, // 100k iteration - brute force'a karşı
    32,
    'sha256'
  );
}

const ENC_KEY = deriveKey(process.env.ENCRYPTION_KEY || crypto.randomBytes(32).toString('hex'));

function encrypt(text) {
  const iv        = crypto.randomBytes(16);          // Her seferinde yeni IV
  const cipher    = crypto.createCipheriv(ALGO, ENC_KEY, iv);
  const encrypted = Buffer.concat([cipher.update(String(text), 'utf8'), cipher.final()]);
  const authTag   = cipher.getAuthTag();             // GCM authentication tag
  // iv:authTag:encrypted — hepsini birleştirip hex'e çevir
  return [iv.toString('hex'), authTag.toString('hex'), encrypted.toString('hex')].join(':');
}

function decrypt(payload) {
  try {
    const [ivHex, tagHex, encHex] = payload.split(':');
    const iv        = Buffer.from(ivHex, 'hex');
    const authTag   = Buffer.from(tagHex, 'hex');
    const encrypted = Buffer.from(encHex, 'hex');
    const decipher  = crypto.createDecipheriv(ALGO, ENC_KEY, iv);
    decipher.setAuthTag(authTag);                    // Tag doğrulaması
    return Buffer.concat([decipher.update(encrypted), decipher.final()]).toString('utf8');
  } catch {
    return null; // Tampered veya geçersiz
  }
}

// ── Güvenli Token Üretici ─────────────────────────────────────────────────
function generateSecureToken(bytes = 32) {
  return crypto.randomBytes(bytes).toString('hex');
}

// ── HMAC İmzası (webhook/link doğrulama için) ────────────────────────────
const HMAC_SECRET = process.env.CSRF_SECRET || crypto.randomBytes(32).toString('hex');

function signData(data) {
  return crypto.createHmac('sha256', HMAC_SECRET)
    .update(JSON.stringify(data))
    .digest('hex');
}

function verifySignature(data, signature) {
  const expected = signData(data);
  // Timing-safe karşılaştırma
  try {
    return crypto.timingSafeEqual(
      Buffer.from(expected, 'hex'),
      Buffer.from(signature, 'hex')
    );
  } catch {
    return false;
  }
}

// ── Gelişmiş Input Sanitizer ──────────────────────────────────────────────
const XSS_OPTIONS = {
  whiteList: {},              // Hiçbir HTML tag'ine izin verme
  stripIgnoreTag: true,
  stripIgnoreTagBody: ['script', 'style', 'iframe', 'object', 'embed'],
  escapeHtml: (str) => str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;'),
};

function sanitizeStr(input, maxLen = 500) {
  if (typeof input !== 'string') return '';
  const cleaned = xss(input.trim(), XSS_OPTIONS);
  return cleaned.substring(0, maxLen);
}

function sanitizeObject(obj, rules = {}) {
  const result = {};
  for (const [key, maxLen] of Object.entries(rules)) {
    if (obj[key] !== undefined) {
      result[key] = sanitizeStr(String(obj[key]), maxLen);
    }
  }
  return result;
}

// ── SQL/NoSQL Injection Pattern Detector ─────────────────────────────────
const INJECTION_PATTERNS = [
  /(\$where|\$regex|\$gt|\$lt|\$ne|\$in|\$nin|\$or|\$and|\$not|\$nor)/i,
  /(union\s+select|select\s+.*\s+from|insert\s+into|drop\s+table|delete\s+from)/i,
  /(exec\s*\(|execute\s*\(|xp_cmdshell|sp_executesql)/i,
  /(<script|javascript:|vbscript:|on\w+\s*=)/i,
  /(\.\.\/|\.\.\\|%2e%2e)/i,  // Path traversal
  /(%00|%0a|%0d|%1a)/i,        // Null bytes
];

function detectInjection(input) {
  if (typeof input !== 'string') return false;
  return INJECTION_PATTERNS.some(p => p.test(input));
}

function scanBody(obj, depth = 0) {
  if (depth > 5) return false;
  if (typeof obj === 'string') return detectInjection(obj);
  if (typeof obj === 'object' && obj !== null) {
    return Object.values(obj).some(v => scanBody(v, depth + 1));
  }
  return false;
}

// ── UID Üretici ───────────────────────────────────────────────────────────
function generateUID() {
  // 128-bit rastgelelik = UUID v4 benzeri ama hex
  return crypto.randomBytes(16).toString('hex');
}

// ── Güvenli Karşılaştırma ─────────────────────────────────────────────────
function safeCompare(a, b) {
  try {
    const ba = Buffer.from(String(a));
    const bb = Buffer.from(String(b));
    if (ba.length !== bb.length) {
      // Uzunluk leak'ini de önle
      crypto.timingSafeEqual(ba, ba);
      return false;
    }
    return crypto.timingSafeEqual(ba, bb);
  } catch {
    return false;
  }
}

module.exports = {
  encrypt, decrypt,
  generateSecureToken, generateUID,
  signData, verifySignature,
  sanitizeStr, sanitizeObject,
  detectInjection, scanBody,
  safeCompare,
};
