// utils/validators.js
const validator = require('validator');

const validateEmail    = (e) => typeof e === 'string' && validator.isEmail(e) && e.length < 100;
const validateUsername = (u) => typeof u === 'string' && /^[a-zA-Z0-9_.]{3,30}$/.test(u);
const validatePassword = (p) =>
  typeof p === 'string' &&
  p.length >= 10 &&         // min 10 karakter
  p.length <= 128 &&
  /[A-Z]/.test(p) &&        // büyük harf
  /[a-z]/.test(p) &&        // küçük harf
  /[0-9]/.test(p) &&        // rakam
  /[^a-zA-Z0-9]/.test(p);  // özel karakter (en güçlü şifre kuralı)

const validateColor    = (c) => typeof c === 'string' && /^#[0-9A-F]{6}$/i.test(c);
const validateText     = (t, max = 5000) => typeof t === 'string' && t.length > 0 && t.length <= max;

module.exports = { validateEmail, validateUsername, validatePassword, validateColor, validateText };
