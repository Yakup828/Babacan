/**
 * ╔══════════════════════════════════════════════════════════════════════════╗
 * ║           LYROX CHAT SERVER v3.0 - MAXIMUM SECURITY EDITION            ║
 * ╠══════════════════════════════════════════════════════════════════════════╣
 * ║  Güvenlik Katmanları:                                                   ║
 * ║  ✅ bcrypt (12 rounds) — Şifreler hash'li, asla plaintext saklanmaz    ║
 * ║  ✅ JWT (HS256) + Server-side Session Store — Token revocation          ║
 * ║  ✅ IP Reputation System — Saldırgan IP'ler otomatik bloklanır         ║
 * ║  ✅ 4-Tier Rate Limiting — Auth, API, Global, Speed                    ║
 * ║  ✅ Brute Force Koruması — 5 hatalı giriş → 15dk block                ║
 * ║  ✅ Timing Attack Koruması — Sabit bcrypt süresi                       ║
 * ║  ✅ AES-256-GCM Şifreleme — Authenticated encryption (tamper-proof)    ║
 * ║  ✅ Injection Scanner — Her body otomatik taranır                      ║
 * ║  ✅ XSS Koruması — xss kütüphanesi + CSP headers                      ║
 * ║  ✅ Helmet.js — 15+ güvenlik başlığı                                   ║
 * ║  ✅ CORS Whitelist — Sadece izinli domain'ler                          ║
 * ║  ✅ HPP + MongoSanitize — HTTP Parameter Pollution + NoSQL injection   ║
 * ║  ✅ Bot/Scanner Detector — Kötü niyetli UA'lar anında bloklanır        ║
 * ║  ✅ Audit Log — Her kritik işlem kayıt altında                         ║
 * ║  ✅ Algorithm Confusion Attack Koruması — JWT sadece HS256              ║
 * ║  ✅ Username Enumeration Koruması — Sabit hata mesajları               ║
 * ║  ✅ Path Traversal Koruması                                             ║
 * ║  ✅ Request Size Limiting — 5MB hard cap                                ║
 * ╚══════════════════════════════════════════════════════════════════════════╝
 */

require('dotenv').config();

// Kritik env kontrolü — production'da eksik config ile çalışma
if (process.env.NODE_ENV === 'production') {
  const required = ['ADMIN_PASS', 'JWT_SECRET', 'CSRF_SECRET', 'ENCRYPTION_KEY'];
  const missing  = required.filter(k => !process.env[k]);
  if (missing.length) {
    console.error('❌ FATAL: Missing required env vars:', missing.join(', '));
    process.exit(1);
  }
  if (process.env.JWT_SECRET.length < 32) {
    console.error('❌ FATAL: JWT_SECRET too short (min 32 chars)');
    process.exit(1);
  }
  if (process.env.ADMIN_PASS.length < 12) {
    console.error('❌ FATAL: ADMIN_PASS too short (min 12 chars)');
    process.exit(1);
  }
}

const express     = require('express');
const path        = require('path');
const compression = require('compression');
const mongoSanitize = require('express-mongo-sanitize');
const bcrypt      = require('bcrypt');

const {
  ipGate, injectionScanner,
  globalLimiter, speedLimiter, apiLimiter,
  helmetConfig, corsConfig, botDetector,
  sizeGuard, extraHeaders, auditMiddleware,
} = require('./middleware/security');

const { DB, audit } = require('./utils/database');
const { generateUID } = require('./utils/security');

const authRoutes  = require('./routes/auth');
const userRoutes  = require('./routes/users');
const apiRoutes   = require('./routes/api');

const app  = express();
const PORT = process.env.PORT || 3000;

// ── Admin Nesnesini Başlat (bcrypt async) ────────────────────────────────
async function initAdmin() {
  const rawPass = process.env.ADMIN_PASS;
  if (!rawPass) {
    console.error('❌ ADMIN_PASS must be set in .env');
    process.exit(1);
  }
  const passwordHash = await bcrypt.hash(rawPass, 12);
  global.ADMIN = {
    uid:          '00000000000000000000000000000000',
    name:         process.env.ADMIN_NAME || 'LyroxPy',
    username:     process.env.ADMIN_USER || 'LyroxPy',
    email:        'admin@lyrox.internal',
    passwordHash,
    avatar:       null,
    online:       false,
    premium:      true,
    nameColor:    '#fbbf24',
    bio:          'Lyrox Yöneticisi',
    admin:        true,
    badgeIcon:    '👨‍💻',
    profileIcon:  '👨‍💻',
    createdAt:    new Date().toISOString(),
  };
  console.log('✅ Admin initialized (password hashed)');
}

// ── Middleware Stack (sıra önemli!) ──────────────────────────────────────
app.set('trust proxy', 1);               // Nginx/proxy arkasında gerçek IP al

app.use(helmetConfig);                   // 1. Security headers (en önce)
app.use(corsConfig);                     // 2. CORS
app.use(extraHeaders);                   // 3. Ek response headers
app.use(auditMiddleware);                // 4. Request/response audit
app.use(ipGate);                         // 5. IP blacklist kontrolü
app.use(botDetector);                    // 6. Bot/scanner tespiti
app.use(globalLimiter);                  // 7. Global rate limit
app.use(speedLimiter);                   // 8. Speed throttle
app.use(sizeGuard);                      // 9. Request boyutu kontrolü
app.use(compression());                  // 10. Gzip
app.use(express.json({ limit: '2mb' })); // 11. JSON parser
app.use(express.urlencoded({ extended: false, limit: '2mb' }));

// 12. Injection / NoSQL sanitize
app.use(mongoSanitize({
  onSanitize: ({ req, key }) => {
    const { addScore } = require('./middleware/security');
    addScore(req.ip, 15);
    audit('NOSQL_INJECTION', req.ip, null, { key });
  },
}));

// 13. XSS + Injection pattern scanner (kendi yazdığımız)
app.use(injectionScanner);

// Timeout koruması
app.use((req, res, next) => {
  req.setTimeout(10000, () => res.status(408).json({ error: 'Request Timeout' }));
  res.setTimeout(15000);
  next();
});

// ── Static Files ──────────────────────────────────────────────────────────
app.use(express.static(path.join(__dirname, 'public'), {
  dotfiles: 'deny',           // .env, .git vb. erişimi engelle
  index:    false,            // Otomatik index açma
  etag:     false,
  setHeaders: (res, filePath) => {
    // Hassas dosyalara erişim engeli
    if (/\.(env|git|json|md|sh|key|pem)$/i.test(filePath)) {
      res.status(403).end();
    }
    res.set('Cache-Control', 'no-store');
  },
}));

// ── Routes ───────────────────────────────────────────────────────────────
app.use('/api/auth',   authRoutes);
app.use('/api/users',  apiLimiter, userRoutes);
app.use('/api',        apiLimiter, apiRoutes);

// ── Health Check (Render/Railway için) ───────────────────────────────────
app.get('/health', (req, res) => {
  res.json({ status: 'ok', uptime: Math.floor(process.uptime()) });
});

// Ana sayfa
app.get('/', (req, res) => {
  res.set({
    'Cache-Control': 'no-store, no-cache, must-revalidate',
    'X-Frame-Options': 'DENY',
  });
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// 404 — path bilgisini sızdırma
app.use((req, res) => {
  res.status(404).json({ error: 'Not Found' });
});

// Global error handler — stack trace sızdırma
app.use((err, req, res, next) => {
  // CORS hatası
  if (err.message === 'CORS Policy Violation') {
    return res.status(403).json({ error: 'CORS Denied' });
  }
  // Diğer hatalar
  console.error('[ERROR]', err.message);
  audit('SERVER_ERROR', req.ip, req.user?.uid, { message: err.message.substring(0, 100) });
  res.status(500).json({ error: 'Internal Server Error' });
});

// ── Session Temizleme (Her 1 saatte expire olmuş session'ları sil) ───────
setInterval(() => {
  const now = Date.now();
  const SEVEN_DAYS = 7 * 24 * 60 * 60 * 1000;
  let cleaned = 0;
  for (const [uid, session] of DB.sessions.entries()) {
    if (now - session.createdAt > SEVEN_DAYS) {
      DB.sessions.delete(uid);
      cleaned++;
    }
  }
  if (cleaned > 0) console.log(`[SESSION] Cleaned ${cleaned} expired sessions`);
}, 60 * 60 * 1000);

// ── Başlat ───────────────────────────────────────────────────────────────
initAdmin().then(() => {
  app.listen(PORT, () => {
    console.log(`
╔═══════════════════════════════════════════════════════════════════╗
║                                                                   ║
║        🔐 LYROX SERVER v3.0 — MAXIMUM SECURITY ONLINE 🔐        ║
║                                                                   ║
║  ✅ bcrypt (12 rounds) — Şifre hash'leme                        ║
║  ✅ JWT HS256 + Session Revocation                               ║
║  ✅ AES-256-GCM Authenticated Encryption                        ║
║  ✅ IP Reputation + Auto-Block System                            ║
║  ✅ 4-Tier Rate Limiting + Brute Force Block                     ║
║  ✅ Timing Attack Koruması                                       ║
║  ✅ Injection Scanner (SQL/NoSQL/XSS/Path Traversal)            ║
║  ✅ Bot/Scanner Auto-Detection & Block                           ║
║  ✅ Helmet + 15+ Security Headers                                ║
║  ✅ CORS Whitelist                                               ║
║  ✅ Audit Log (tüm kritik işlemler)                             ║
║  ✅ Username Enumeration Koruması                                ║
║  ✅ Algorithm Confusion Attack Koruması                          ║
║  ✅ Session Store + Token Revocation                             ║
║                                                                   ║
║  Port: ${PORT}                                                       ║
╚═══════════════════════════════════════════════════════════════════╝
    `);

  // ── Keep-Alive (Render ücretsiz planda uyumasın) ─────────────────────
  const siteUrl = process.env.RENDER_EXTERNAL_URL;
  if (siteUrl) {
    setInterval(async () => {
      try {
        await fetch(`${siteUrl}/health`);
        console.log('[KEEP-ALIVE] Ping OK');
      } catch (e) {
        console.warn('[KEEP-ALIVE] Ping failed:', e.message);
      }
    }, 14 * 60 * 1000); // Her 14 dakikada bir ping — Render 15dk'da uyutur
    console.log(`[KEEP-ALIVE] Aktif → ${siteUrl}`);
  }
  });
});

// Çökme koruması — beklenmedik hata olursa sessizce kapat
process.on('uncaughtException', (err) => {
  console.error('[FATAL] Uncaught Exception:', err.message);
  process.exit(1);
});
process.on('unhandledRejection', (reason) => {
  console.error('[FATAL] Unhandled Rejection:', reason);
  process.exit(1);
});
