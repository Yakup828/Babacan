// routes/auth.js
const router   = require('express').Router();
const bcrypt   = require('bcrypt');
const { authLimiter, hashToken, signJWT, addScore } = require('../middleware/security');
const { DB, audit, publicUser, findByIdent } = require('../utils/database');
const { sanitizeStr, generateUID, safeCompare } = require('../utils/security');
const { validateEmail, validateUsername, validatePassword } = require('../utils/validators');

const SALT_ROUNDS = 12;

// ── POST /api/auth/login ─────────────────────────────────────────────────
router.post('/login', authLimiter, async (req, res) => {
  const { ident, pass } = req.body;

  // Tip ve boyut kontrolü
  if (!ident || !pass || typeof ident !== 'string' || typeof pass !== 'string') {
    return res.status(400).json({ success: false, error: 'Invalid input' });
  }
  if (ident.length > 100 || pass.length > 128) {
    addScore(req.ip, 5);
    return res.status(400).json({ success: false, error: 'Invalid input' });
  }

  // Timing Attack Koruması:
  // Her durumda bcrypt çalışır, kullanıcı bulunsun ya da bulunmasın
  const DUMMY_HASH = '$2b$12$invalidhashfortimingprotectionXXXXXXXXXXXXXXXXXXXXX';

  let foundUser = null;
  const identLower = ident.toLowerCase();

  // Admin mi?
  if (identLower === global.ADMIN.username.toLowerCase() ||
      identLower === global.ADMIN.email.toLowerCase()) {
    foundUser = global.ADMIN;
  } else {
    foundUser = findByIdent(ident);
  }

  const hashToCheck = foundUser ? foundUser.passwordHash : DUMMY_HASH;

  // bcrypt.compare her zaman çalışır (sabit süre)
  const match = await bcrypt.compare(pass, hashToCheck);

  if (!match || !foundUser) {
    addScore(req.ip, 10);
    audit('FAILED_LOGIN', req.ip, null, { ident: identLower.substring(0, 30) });
    // Aynı hata mesajı — kullanıcı adı/email enumeration'ı önle
    return res.status(401).json({ success: false, error: 'Invalid credentials' });
  }

  // Aktif session kontrolü - aynı kullanıcı birden fazla login yapabilir
  // (multi-device desteği) ama limit koy
  foundUser.online = true;

  const token = signJWT({
    uid:      foundUser.uid,
    username: foundUser.username,
    admin:    !!foundUser.admin,
  });

  // Session kaydını güncelle
  DB.sessions.set(foundUser.uid, {
    tokenHash: hashToken(token),
    createdAt: Date.now(),
    lastSeen:  Date.now(),
    ip:        req.ip,
    ua:        req.get('user-agent')?.substring(0, 200),
  });

  audit('LOGIN', req.ip, foundUser.uid);

  return res.json({
    success: true,
    token,
    user: publicUser(foundUser),
    isAdmin: !!foundUser.admin,
  });
});

// ── POST /api/auth/register ──────────────────────────────────────────────
router.post('/register', authLimiter, async (req, res) => {
  let { name, email, username, password } = req.body;

  if (!name || !email || !username || !password) {
    return res.status(400).json({ success: false, error: 'All fields required' });
  }

  // Tip kontrolü
  for (const v of [name, email, username, password]) {
    if (typeof v !== 'string') return res.status(400).json({ success: false, error: 'Invalid type' });
  }

  // Boyut kontrolü
  if (name.length < 2 || name.length > 50)  return res.status(400).json({ success: false, error: 'Invalid name length' });
  if (!validateUsername(username))            return res.status(400).json({ success: false, error: 'Invalid username' });
  if (!validatePassword(password))            return res.status(400).json({ success: false, error: 'Password too weak (min 10 chars, uppercase, lowercase, number, symbol)' });
  if (!validateEmail(email))                  return res.status(400).json({ success: false, error: 'Invalid email' });

  // Sanitize
  name     = sanitizeStr(name, 50);
  username = sanitizeStr(username, 30);
  email    = sanitizeStr(email.toLowerCase(), 100);

  // Duplicate kontrolü (sabit zamanlı değil ama bu kabul edilebilir)
  const userLow = username.toLowerCase();
  if (userLow === global.ADMIN.username.toLowerCase()) {
    return res.status(400).json({ success: false, error: 'Username taken' });
  }
  if (DB.users.find(u => u.username.toLowerCase() === userLow)) {
    return res.status(400).json({ success: false, error: 'Username taken' });
  }
  if (DB.users.find(u => u.email === email)) {
    return res.status(400).json({ success: false, error: 'Email already registered' });
  }

  // Şifreyi hash'le
  const passwordHash = await bcrypt.hash(password, SALT_ROUNDS);

  const newUser = {
    uid:          generateUID(),
    name, username, email, passwordHash,
    avatar:       null,
    online:       true,
    premium:      false,
    nameColor:    '#f0f0f0',
    bio:          '',
    admin:        false,
    badgeIcon:    '',
    profileIcon:  '',
    createdAt:    new Date().toISOString(),
  };

  DB.users.push(newUser);

  const token = signJWT({
    uid:      newUser.uid,
    username: newUser.username,
    admin:    false,
  });

  DB.sessions.set(newUser.uid, {
    tokenHash: hashToken(token),
    createdAt: Date.now(),
    lastSeen:  Date.now(),
    ip:        req.ip,
    ua:        req.get('user-agent')?.substring(0, 200),
  });

  audit('REGISTER', req.ip, newUser.uid, { username: newUser.username });

  return res.status(201).json({
    success: true,
    token,
    user: publicUser(newUser),
  });
});

// ── POST /api/auth/logout ────────────────────────────────────────────────
router.post('/logout', require('../middleware/security').requireAuth, (req, res) => {
  const user = DB.users.find(u => u.uid === req.user.uid);
  if (user) user.online = false;
  if (req.user.uid === global.ADMIN?.uid) global.ADMIN.online = false;

  // Session'ı geçersiz kıl (token revocation)
  DB.sessions.delete(req.user.uid);

  audit('LOGOUT', req.ip, req.user.uid);
  return res.json({ success: true });
});

module.exports = router;
