// routes/users.js
const router = require('express').Router();
const bcrypt = require('bcrypt');
const { requireAuth } = require('../middleware/security');
const { DB, publicUser, findUser } = require('../utils/database');
const { sanitizeStr } = require('../utils/security');
const { validateUsername, validatePassword, validateColor } = require('../utils/validators');

const SALT_ROUNDS = 12;

// GET /api/users — aktif kullanıcı listesi (sadece public bilgiler)
router.get('/', requireAuth, (req, res) => {
  const list = DB.users.map(u => publicUser(u));
  // Admin'i de ekle (online durumu için)
  if (global.ADMIN) list.push(publicUser(global.ADMIN));
  res.json(list);
});

// PUT /api/users/me — kendi profilini güncelle
router.put('/me', requireAuth, async (req, res) => {
  const { name, username, bio, nameColor, badgeIcon, profileIcon, oldPassword, newPassword } = req.body;

  // Admin kendi profilini güncelleyemez bu endpoint'ten (ayrı route lazım)
  const user = findUser(req.user.uid);
  if (!user) return res.status(404).json({ success: false, error: 'User not found' });

  // Başka kullanıcının profilini güncellemeye çalışıyor mu? (paranoya kontrolü)
  if (user.uid !== req.user.uid) {
    return res.status(403).json({ success: false, error: 'Forbidden' });
  }

  // Alan güncellemeleri
  if (name !== undefined) {
    if (typeof name !== 'string' || name.length < 2 || name.length > 50) {
      return res.status(400).json({ success: false, error: 'Invalid name' });
    }
    user.name = sanitizeStr(name, 50);
  }

  if (username !== undefined) {
    if (!validateUsername(username)) {
      return res.status(400).json({ success: false, error: 'Invalid username' });
    }
    const uLow = username.toLowerCase();
    if (uLow !== user.username.toLowerCase()) {
      if (uLow === global.ADMIN?.username.toLowerCase()) {
        return res.status(400).json({ success: false, error: 'Username taken' });
      }
      const conflict = DB.users.find(u => u.uid !== user.uid && u.username.toLowerCase() === uLow);
      if (conflict) return res.status(400).json({ success: false, error: 'Username taken' });
    }
    user.username = sanitizeStr(username, 30);
  }

  if (bio !== undefined) {
    if (typeof bio !== 'string' || bio.length > 500) {
      return res.status(400).json({ success: false, error: 'Bio too long' });
    }
    user.bio = sanitizeStr(bio, 500);
  }

  if (nameColor !== undefined) {
    // Gradient veya hex renk
    if (validateColor(nameColor) || (typeof nameColor === 'string' && nameColor.startsWith('linear-gradient'))) {
      user.nameColor = nameColor;
    }
  }

  if (badgeIcon !== undefined)   user.badgeIcon   = typeof badgeIcon === 'string'   ? badgeIcon.substring(0, 10)   : '';
  if (profileIcon !== undefined) user.profileIcon = typeof profileIcon === 'string' ? profileIcon.substring(0, 10) : '';

  // Şifre değiştirme
  if (newPassword !== undefined) {
    if (!oldPassword || typeof oldPassword !== 'string') {
      return res.status(400).json({ success: false, error: 'Current password required' });
    }
    const match = await bcrypt.compare(oldPassword, user.passwordHash);
    if (!match) return res.status(400).json({ success: false, error: 'Current password is wrong' });
    if (!validatePassword(newPassword)) {
      return res.status(400).json({ success: false, error: 'New password too weak' });
    }
    if (oldPassword === newPassword) {
      return res.status(400).json({ success: false, error: 'New password must be different' });
    }
    user.passwordHash = await bcrypt.hash(newPassword, SALT_ROUNDS);
  }

  return res.json({ success: true, user: publicUser(user) });
});

// PUT /api/users/avatar — avatar güncelle (base64)
router.put('/avatar', requireAuth, (req, res) => {
  const { avatar } = req.body;
  const user = findUser(req.user.uid);
  if (!user) return res.status(404).json({ success: false });

  if (avatar === null) {
    user.avatar = null;
    return res.json({ success: true });
  }

  if (typeof avatar !== 'string' || !avatar.startsWith('data:image/')) {
    return res.status(400).json({ success: false, error: 'Invalid image format' });
  }

  // Boyut kontrolü (~2MB base64)
  if (avatar.length > 2.5 * 1024 * 1024) {
    return res.status(413).json({ success: false, error: 'Image too large (max 2MB)' });
  }

  user.avatar = avatar;
  return res.json({ success: true, user: publicUser(user) });
});

module.exports = router;
